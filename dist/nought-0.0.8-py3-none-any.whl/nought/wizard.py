import sys
def main():
	print('Hello, this tool isn\'t ready yet. Please ignore!')
	sys.exit(0)