import sys
def main():
	# print('Hello, this will help you schedule !')
	sys.exit(0)