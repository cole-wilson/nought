# nought
A super customizable file cleaner/organizer/automator.
