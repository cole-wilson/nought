import os

from shutil import which
if which('nought') is not None:
	os.system("osascript -e 'display alert \"This script will install nought on this system. Please quit to stop.\"'")
	with open(os.path.expanduser('~')+".profile",'w+') as profile:
		profile.write(
			profile.read()+f"alias nought='{__file__}'"
		)
