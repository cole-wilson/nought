import sys, os, toml 
def main():
	# sys.exit(0)
	print('Hello! The best way to setup nought is to go to the github page:\n\thttps://github.com/cole-wilson/nought#configuration')
	# mode = input("\nYou have several choices:\n\t\1:Create a config file.\n\t2: Edit an existing config file.\n\t(your choice must be an integer)\n>>> ")
	# try:
	# 	mode = int(mode)
	# except:
	# 	print("You have to chose an integer!")
	# if mode == 1:
	# 	fname = input('Please type the path to your pre-existing file.\n>>> ')
	# 	fname = os.path.abspath(fname)
	# 	try:
	# 		conf = toml.loads(open(fname).read())
	# 		print(conf)
	# 	except toml.decoder.TomlDecodeError as error:
	# 		print("This file is malformed:\n\t"+str(error)+"\nPlease fix!")
	# 		sys.exit(1)
	# 	except IsADirectoryError:
	# 		print('That path is a directory!')
	# 		sys.exit(1)
	# 	except FileNotFoundError:
	# 		print('That path doesn\'t exist!')
	# 		sys.exit(1)
	# 	for group in conf["group"]:
	# 		t = input("Please enter a cron style time for when I should run this command:\n>>> ")
	sys.exit(0)